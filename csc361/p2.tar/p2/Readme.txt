Author: Nicholas Wurzer
V00958568
CSC361
Kui Wu
March 6, 2022

To run this program, ensure that tcpsummary.py is executable and execute 
the program with the name of the desired capture file if the capture file 
is in the same directory as the executable or the capture file's absolute
 path as the only argument.

For example I ran './tcpsummary.py sample-capture-file.cap' to test my program.

Output is printed to the the console.

With other coursework, I didn't quite get there.  Nevertheless I feel like I got a
much better understanding of the TCP layer from this assignment.  Thank you very much for the extension
professor Wu, it is much appreciated!