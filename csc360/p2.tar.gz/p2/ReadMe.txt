Nick Wurzer
V00958568
csc360
Jianping Pan
University of Victoria

First run the makefile.
Ensure that the input file you wish to test is in the same directory as mts.
Run mts with one argument -the input file you wish to test.
For example, I currently run './mts input1.txt'

Some code borrowed from loading_train.c provided by Jianping Pan at University of Victoria.

I have not had the time that I would like to dedicate towards this assignment, so it is not complete.
The parts that I have completed so far are: 
1)Reading the input file.
2)Creating the correct number trains based on that input.
3)Loading trains based on the specified input time.

Design changes:
I have changed from using a linked list, to a dynamic array since it was easier to impliment.