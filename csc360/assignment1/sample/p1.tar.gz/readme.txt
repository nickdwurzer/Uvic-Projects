Author: Nick Wurzer
V00958568
February 11, 2022
CSC360
Professor Jianping Pan
University of Victoria

As mentioned in the first line of the program, the code skeleton is adapted from the sample.c program supplied by the teaching team.
Currently, the background processes are not implimented, however the basic execution and changing directories is implimented.
The command to exit the program is 'bye'.
The program does not distinguish between error types when changing directories, only displaying if some error has occurred.
Likewise if an error occurs executing a program, a general error message is displayed and the child process to execute the program is killed.

